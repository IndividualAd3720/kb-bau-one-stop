document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const clearSearch = document.getElementById('clearSearch');
    const categoriesContainer = document.getElementById('categoriesContainer');
    const searchResults = document.getElementById('searchResults');
    const resultsContainer = document.getElementById('resultsContainer');

    if (!searchInput) return;

    searchInput.addEventListener('input', function() {
        const query = this.value.trim().toLowerCase();
        
        if (query.length > 0) {
            clearSearch.style.display = 'block';
            performSearch(query);
        } else {
            clearSearch.style.display = 'none';
            hideSearchResults();
        }
    });

    clearSearch.addEventListener('click', function() {
        searchInput.value = '';
        this.style.display = 'none';
        hideSearchResults();
        searchInput.focus();
    });

    function performSearch(query) {
        const allArticles = document.querySelectorAll('.article-card');
        const results = [];

        allArticles.forEach(article => {
            const title = article.dataset.title.toLowerCase();
            const description = article.dataset.description.toLowerCase();
            const category = article.dataset.category.toLowerCase();
            
            if (title.includes(query) || description.includes(query) || category.includes(query)) {
                results.push({
                    element: article.cloneNode(true),
                    relevance: calculateRelevance(query, title, description)
                });
            }
        });

        results.sort((a, b) => b.relevance - a.relevance);
        displaySearchResults(results, query);
    }

    function calculateRelevance(query, title, description) {
        let score = 0;
        if (title.includes(query)) score += 10;
        if (title.startsWith(query)) score += 5;
        if (description.includes(query)) score += 3;
        return score;
    }

    function displaySearchResults(results, query) {
        categoriesContainer.style.display = 'none';
        searchResults.style.display = 'block';

        if (results.length === 0) {
            resultsContainer.innerHTML = `
                <div class="no-results">
                    <i class="fas fa-search"></i>
                    <h3>No results found for "${query}"</h3>
                    <p>Try different keywords or browse categories below</p>
                </div>
            `;
        } else {
            resultsContainer.innerHTML = `
                <p style="color: var(--text-secondary); margin-bottom: 1rem;">
                    Found ${results.length} result${results.length !== 1 ? 's' : ''} for "${query}"
                </p>
                <div class="articles-grid">
                    ${results.map(r => r.element.outerHTML).join('')}
                </div>
            `;
        }
    }

    function hideSearchResults() {
        searchResults.style.display = 'none';
        categoriesContainer.style.display = 'block';
    }
});
