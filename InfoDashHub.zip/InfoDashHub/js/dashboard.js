function handleTileClick(tileName) {
    const tileActions = {
        'performance-dashboard': 'Opening Performance Dashboard...',
        'monthly-reports': 'Loading Monthly Reports...',
        'analytics-suite': 'Launching Analytics Suite...',
        'export-data': 'Preparing Data Export...',
        'task-manager': 'Opening Task Manager...',
        'schedule-planner': 'Loading Schedule Planner...',
        'team-directory': 'Opening Team Directory...',
        'notifications': 'Viewing Notifications...',
        'system-settings': 'Accessing System Settings...',
        'database-manager': 'Opening Database Manager...',
        'security-center': 'Entering Security Center...',
        'backup-restore': 'Loading Backup & Restore...',
        'support-portal': 'Connecting to Support Portal...',
        'training-center': 'Opening Training Center...',
        'email-center': 'Launching Email Center...'
    };

    const message = tileActions[tileName] || 'Opening tool...';
    
    showNotification(message, 'info');
    
    console.log(`Tile clicked: ${tileName}`);
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    Object.assign(notification.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '1rem 1.5rem',
        backgroundColor: type === 'info' ? '#6366f1' : '#10b981',
        color: 'white',
        borderRadius: '0.5rem',
        boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
        zIndex: '9999',
        animation: 'slideIn 0.3s ease',
        maxWidth: '300px'
    });

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
