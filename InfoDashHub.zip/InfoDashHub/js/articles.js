const articles = {
    'welcome': {
        title: 'Welcome Guide',
        category: 'Getting Started',
        content: `
            <h1>Welcome to the Knowledge Base</h1>
            <p>Thank you for choosing our platform! This guide will help you get started and make the most of our Knowledge Base and BAU Dashboard.</p>
            
            <h2>What is the Knowledge Base?</h2>
            <p>The Knowledge Base is your central resource for:</p>
            <ul>
                <li>Documentation and technical guides</li>
                <li>Frequently Asked Questions (FAQs)</li>
                <li>Step-by-step tutorials</li>
                <li>Best practices and tips</li>
            </ul>

            <h2>Navigation</h2>
            <p>Browse content by category or use the search bar at the top to find specific information. All articles are organized into four main categories:</p>
            <ul>
                <li><strong>Getting Started:</strong> Essential guides for new users</li>
                <li><strong>FAQs:</strong> Answers to common questions</li>
                <li><strong>Tutorials:</strong> Detailed walkthroughs</li>
                <li><strong>Documentation:</strong> Technical reference materials</li>
            </ul>

            <h2>Tips for Success</h2>
            <ul>
                <li>Use the search feature to quickly find what you need</li>
                <li>Bookmark frequently accessed articles</li>
                <li>Check the documentation for technical details</li>
                <li>Visit the BAU Dashboard for quick access to tools</li>
            </ul>
        `
    },
    'quick-start': {
        title: 'Quick Start Tutorial',
        category: 'Getting Started',
        content: `
            <h1>Quick Start Tutorial</h1>
            <p>Get up and running in just 5 minutes with this quick start guide!</p>

            <h2>Step 1: Explore the Dashboard</h2>
            <p>Visit the BAU Dashboard to see all available tools and resources. The dashboard provides quick access to:</p>
            <ul>
                <li>Performance reports and analytics</li>
                <li>Operational tools and task management</li>
                <li>System settings and configuration</li>
                <li>Quick links to frequently used resources</li>
            </ul>

            <h2>Step 2: Customize Your Theme</h2>
            <p>Toggle between light and dark mode using the theme button in the navigation bar. Your preference will be saved automatically.</p>

            <h2>Step 3: Search for Information</h2>
            <p>Use the search bar on the Knowledge Base page to find specific articles, tutorials, or documentation.</p>

            <h2>Step 4: Access Tools</h2>
            <p>Click on any dashboard tile to access the corresponding tool or resource. Each tile provides a direct link to its functionality.</p>

            <h2>Next Steps</h2>
            <p>Now that you're familiar with the basics, explore more advanced features in our tutorials section!</p>
        `
    },
    'requirements': {
        title: 'System Requirements',
        category: 'Getting Started',
        content: `
            <h1>System Requirements</h1>
            <p>Ensure your system meets the following requirements for optimal performance.</p>

            <h2>Browser Compatibility</h2>
            <p>This platform works best with modern browsers:</p>
            <ul>
                <li>Chrome 90 or higher</li>
                <li>Firefox 88 or higher</li>
                <li>Safari 14 or higher</li>
                <li>Edge 90 or higher</li>
            </ul>

            <h2>Device Requirements</h2>
            <ul>
                <li><strong>Desktop:</strong> Any modern computer with 4GB+ RAM</li>
                <li><strong>Mobile:</strong> iOS 13+ or Android 8+</li>
                <li><strong>Tablet:</strong> iPad OS 13+ or Android 8+</li>
            </ul>

            <h2>Network Requirements</h2>
            <p>A stable internet connection is recommended for the best experience. Minimum bandwidth: 5 Mbps.</p>

            <h2>Screen Resolution</h2>
            <p>Minimum recommended resolution: 1280x720. The interface is fully responsive and adapts to all screen sizes.</p>
        `
    },
    'account-faq': {
        title: 'Account Management FAQs',
        category: 'FAQs',
        content: `
            <h1>Account Management FAQs</h1>

            <h2>How do I update my profile?</h2>
            <p>Navigate to System Settings from the BAU Dashboard, then select "Profile Settings" to update your information.</p>

            <h2>Can I change my password?</h2>
            <p>Yes, go to Security Center and select "Change Password" to update your credentials securely.</p>

            <h2>How do I manage notifications?</h2>
            <p>Access the Notifications tile on the dashboard to configure your notification preferences.</p>

            <h2>What if I forget my password?</h2>
            <p>Use the "Forgot Password" link on the login page to reset your password via email.</p>

            <h2>Can I have multiple accounts?</h2>
            <p>Each user should maintain one primary account. Contact support if you need special arrangements.</p>
        `
    },
    'troubleshooting': {
        title: 'Troubleshooting Guide',
        category: 'FAQs',
        content: `
            <h1>Troubleshooting Common Issues</h1>

            <h2>Page Not Loading</h2>
            <p>If a page isn't loading properly:</p>
            <ul>
                <li>Clear your browser cache and cookies</li>
                <li>Try a different browser</li>
                <li>Check your internet connection</li>
                <li>Disable browser extensions temporarily</li>
            </ul>

            <h2>Dashboard Tiles Not Working</h2>
            <p>Ensure JavaScript is enabled in your browser settings. Most features require JavaScript to function properly.</p>

            <h2>Search Not Returning Results</h2>
            <p>Try different keywords or browse categories manually. The search function looks for exact matches in titles and descriptions.</p>

            <h2>Theme Not Saving</h2>
            <p>Make sure your browser allows localStorage. Check your privacy settings and disable "Block third-party cookies" if enabled.</p>

            <h2>Still Having Issues?</h2>
            <p>Visit the Support Portal from the dashboard or contact our technical support team.</p>
        `
    },
    'best-practices': {
        title: 'Best Practices',
        category: 'FAQs',
        content: `
            <h1>Best Practices for Optimal Usage</h1>

            <h2>Organization</h2>
            <ul>
                <li>Bookmark frequently accessed pages</li>
                <li>Use the search feature to save time</li>
                <li>Organize your dashboard tiles by priority</li>
                <li>Keep your browser updated</li>
            </ul>

            <h2>Security</h2>
            <ul>
                <li>Use a strong, unique password</li>
                <li>Enable two-factor authentication if available</li>
                <li>Log out when using shared devices</li>
                <li>Regularly review your security settings</li>
            </ul>

            <h2>Performance</h2>
            <ul>
                <li>Close unused tabs to free up memory</li>
                <li>Clear cache periodically</li>
                <li>Use a stable internet connection</li>
                <li>Update your browser regularly</li>
            </ul>

            <h2>Productivity</h2>
            <ul>
                <li>Customize your dashboard for quick access</li>
                <li>Learn keyboard shortcuts</li>
                <li>Use the dark theme to reduce eye strain</li>
                <li>Schedule regular reviews of documentation updates</li>
            </ul>
        `
    },
    'advanced': {
        title: 'Advanced Features',
        category: 'Tutorials',
        content: `
            <h1>Advanced Features Tutorial</h1>

            <h2>Customization Options</h2>
            <p>Unlock advanced customization features to tailor the platform to your needs.</p>

            <h3>Theme Customization</h3>
            <p>Beyond light and dark mode, you can customize colors and layouts through the System Settings.</p>

            <h3>Dashboard Personalization</h3>
            <p>Rearrange tiles, create custom shortcuts, and configure which sections appear on your dashboard.</p>

            <h2>Advanced Search Techniques</h2>
            <ul>
                <li>Use specific keywords for precise results</li>
                <li>Search within categories for focused results</li>
                <li>Combine multiple search terms</li>
            </ul>

            <h2>Automation Features</h2>
            <p>Set up automated reports, scheduled tasks, and custom notifications to streamline your workflow.</p>

            <h2>Integration Capabilities</h2>
            <p>Connect with third-party tools and services to extend functionality and improve productivity.</p>
        `
    },
    'integration': {
        title: 'Integration Guide',
        category: 'Tutorials',
        content: `
            <h1>Integration Guide</h1>

            <h2>Connecting Third-Party Services</h2>
            <p>Enhance your workflow by integrating with popular tools and services.</p>

            <h3>Available Integrations</h3>
            <ul>
                <li>Email services (Gmail, Outlook)</li>
                <li>Project management tools (Trello, Asana)</li>
                <li>Communication platforms (Slack, Teams)</li>
                <li>Cloud storage (Google Drive, Dropbox)</li>
            </ul>

            <h2>Setup Process</h2>
            <ol>
                <li>Navigate to System Settings</li>
                <li>Select "Integrations"</li>
                <li>Choose your service and click "Connect"</li>
                <li>Authorize access through OAuth</li>
                <li>Configure integration settings</li>
            </ol>

            <h2>Managing Integrations</h2>
            <p>View, edit, or remove integrations at any time through the System Settings panel.</p>

            <h2>Troubleshooting</h2>
            <p>If an integration isn't working, try disconnecting and reconnecting it. Check that all required permissions are granted.</p>
        `
    },
    'automation': {
        title: 'Automation Tutorial',
        category: 'Tutorials',
        content: `
            <h1>Automation Tutorial</h1>

            <h2>Streamline Your Workflow</h2>
            <p>Learn how to automate repetitive tasks and save time with built-in automation features.</p>

            <h3>Automated Reports</h3>
            <p>Schedule reports to be generated and delivered automatically:</p>
            <ol>
                <li>Go to Reports & Analytics</li>
                <li>Select the report type</li>
                <li>Click "Schedule"</li>
                <li>Choose frequency and recipients</li>
            </ol>

            <h3>Task Automation</h3>
            <p>Create automated workflows for common tasks:</p>
            <ul>
                <li>Set up triggers based on specific events</li>
                <li>Define actions to be performed automatically</li>
                <li>Configure conditions and rules</li>
            </ul>

            <h3>Notification Automation</h3>
            <p>Automatically receive notifications for important events and updates based on your preferences.</p>

            <h2>Best Practices</h2>
            <ul>
                <li>Start with simple automations</li>
                <li>Test thoroughly before deploying</li>
                <li>Monitor automated tasks regularly</li>
                <li>Document your automation workflows</li>
            </ul>
        `
    },
    'api': {
        title: 'API Reference',
        category: 'Documentation',
        content: `
            <h1>API Reference</h1>

            <h2>Overview</h2>
            <p>Access platform features programmatically using our RESTful API.</p>

            <h3>Base URL</h3>
            <code>https://api.example.com/v1</code>

            <h3>Authentication</h3>
            <p>All API requests require authentication using an API key:</p>
            <pre><code>Authorization: Bearer YOUR_API_KEY</code></pre>

            <h2>Common Endpoints</h2>

            <h3>Get User Profile</h3>
            <pre><code>GET /user/profile</code></pre>

            <h3>List Articles</h3>
            <pre><code>GET /articles</code></pre>

            <h3>Search</h3>
            <pre><code>GET /search?q=query</code></pre>

            <h2>Rate Limits</h2>
            <p>API requests are limited to 1000 calls per hour per API key.</p>

            <h2>Error Codes</h2>
            <ul>
                <li><code>400</code> - Bad Request</li>
                <li><code>401</code> - Unauthorized</li>
                <li><code>404</code> - Not Found</li>
                <li><code>429</code> - Rate Limit Exceeded</li>
                <li><code>500</code> - Internal Server Error</li>
            </ul>
        `
    },
    'configuration': {
        title: 'Configuration Guide',
        category: 'Documentation',
        content: `
            <h1>Configuration Guide</h1>

            <h2>System Settings</h2>
            <p>Configure the platform to match your organizational needs.</p>

            <h3>General Settings</h3>
            <ul>
                <li><strong>Language:</strong> Choose your preferred language</li>
                <li><strong>Time Zone:</strong> Set your local time zone</li>
                <li><strong>Date Format:</strong> Configure date display format</li>
            </ul>

            <h3>Display Settings</h3>
            <ul>
                <li><strong>Theme:</strong> Light or dark mode</li>
                <li><strong>Density:</strong> Compact or comfortable view</li>
                <li><strong>Font Size:</strong> Adjust text size</li>
            </ul>

            <h3>Notification Settings</h3>
            <ul>
                <li>Email notifications</li>
                <li>In-app alerts</li>
                <li>Frequency preferences</li>
            </ul>

            <h3>Privacy Settings</h3>
            <ul>
                <li>Data sharing preferences</li>
                <li>Cookie settings</li>
                <li>Analytics opt-in/out</li>
            </ul>

            <h2>Advanced Configuration</h2>
            <p>Contact your system administrator for advanced configuration options including custom domains, SSO setup, and enterprise features.</p>
        `
    },
    'security': {
        title: 'Security & Privacy',
        category: 'Documentation',
        content: `
            <h1>Security & Privacy</h1>

            <h2>Our Security Commitment</h2>
            <p>We take your security and privacy seriously. This document outlines our security measures and privacy practices.</p>

            <h3>Data Encryption</h3>
            <ul>
                <li>All data in transit is encrypted using TLS 1.3</li>
                <li>Data at rest is encrypted using AES-256</li>
                <li>End-to-end encryption for sensitive communications</li>
            </ul>

            <h3>Access Control</h3>
            <ul>
                <li>Role-based access control (RBAC)</li>
                <li>Multi-factor authentication (MFA) support</li>
                <li>Session management and timeout</li>
                <li>IP whitelisting options</li>
            </ul>

            <h3>Data Privacy</h3>
            <ul>
                <li>GDPR compliant</li>
                <li>Data minimization principles</li>
                <li>Right to access and delete data</li>
                <li>No sale of personal information</li>
            </ul>

            <h2>Security Best Practices</h2>
            <ul>
                <li>Use strong, unique passwords</li>
                <li>Enable two-factor authentication</li>
                <li>Regularly review access logs</li>
                <li>Report suspicious activity immediately</li>
            </ul>

            <h2>Compliance</h2>
            <p>We maintain compliance with industry standards including SOC 2, ISO 27001, and GDPR.</p>
        `
    }
};

document.addEventListener('DOMContentLoaded', function() {
    const articleLinks = document.querySelectorAll('.article-link');
    const articleView = document.getElementById('articleView');
    const categoriesContainer = document.getElementById('categoriesContainer');
    const searchResults = document.getElementById('searchResults');
    const articleContent = document.getElementById('articleContent');
    const backButton = document.getElementById('backToCategories');
    const breadcrumb = document.getElementById('breadcrumb');

    articleLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const articleId = this.dataset.article;
            showArticle(articleId);
        });
    });

    if (backButton) {
        backButton.addEventListener('click', function() {
            hideArticle();
        });
    }

    function showArticle(articleId) {
        const article = articles[articleId];
        if (!article) return;

        categoriesContainer.style.display = 'none';
        searchResults.style.display = 'none';
        articleView.style.display = 'block';
        articleContent.innerHTML = article.content;
        breadcrumb.innerHTML = `<a href="#">Home</a> / <a href="#">${article.category}</a> / ${article.title}`;
        
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function hideArticle() {
        articleView.style.display = 'none';
        categoriesContainer.style.display = 'block';
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
});
