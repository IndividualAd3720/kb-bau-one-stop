# Knowledge Base & BAU Dashboard

## Overview

A static, multi-page web application that provides a centralized hub for knowledge management and business operations. The application consists of three main pages: a landing page, a knowledge base with search functionality, and a BAU (Business As Usual) dashboard with quick-access tiles. Built entirely with vanilla HTML, CSS, and JavaScript with no backend dependencies, making it ideal for GitHub Pages deployment.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Pure Static SPA-like Structure**: The application uses a multi-page architecture with three distinct HTML files (index.html, knowledge-base.html, dashboard.html) that share common CSS and JavaScript modules. This approach was chosen to:
- Eliminate the need for build tools or bundlers
- Enable direct deployment to GitHub Pages without configuration
- Provide instant page loads with no server-side rendering
- Maintain simplicity while allowing modular code organization

**CSS Architecture - Modular Theming System**: Styles are separated into four distinct files:
- `main.css`: Core layout, components, and base styles
- `theme.css`: Dark/light theme variable overrides
- `knowledge-base.css`: Page-specific styles for the knowledge base
- `dashboard.css`: Page-specific styles for the dashboard

This separation allows for:
- Easy theme switching without duplicating styles
- Page-specific styling without bloat
- CSS variable-based theming that updates dynamically

**JavaScript Module Pattern**: Five separate JS files handle distinct concerns:
- `main.js`: Mobile navigation and menu interactions
- `theme-toggle.js`: Theme persistence using localStorage
- `search.js`: Real-time search with relevance scoring
- `articles.js`: Article content storage and navigation
- `dashboard.js`: Dashboard tile interactions and notifications

This modular approach provides clear separation of concerns while avoiding the complexity of a build system.

### Data Storage Solutions

**LocalStorage for Preferences**: User theme preferences (dark/light mode) are persisted in browser localStorage. This approach was selected because:
- No server-side storage is required
- Preferences persist across sessions
- Simple API with no external dependencies
- Suitable for the limited scope of stored data

**In-Memory Article Storage**: Knowledge base articles are stored as JavaScript objects in `articles.js`. This solution:
- Eliminates the need for a database or CMS
- Provides instant search without API calls
- Allows easy content updates through simple JavaScript edits
- Keeps the entire application self-contained

### UI/UX Design Patterns

**CSS Custom Properties for Theming**: The entire color scheme and spacing system uses CSS variables defined in `:root`. Dark theme overrides are applied via `[data-theme="dark"]` attribute selector. Benefits include:
- Instant theme switching without page reload
- Consistent spacing and color usage across components
- Easy maintenance and customization
- No JavaScript required for style updates

**Mobile-First Responsive Design**: The layout uses CSS Grid and Flexbox with mobile breakpoints. The navigation collapses to a hamburger menu on smaller screens, providing optimal UX across devices without requiring separate mobile templates.

**Component-Based Card System**: Both the knowledge base and dashboard use a card-based UI pattern with consistent styling (shadows, borders, hover effects). This creates visual consistency and familiar interaction patterns across different sections.

### Search Functionality

**Client-Side Search with Relevance Ranking**: The search implementation uses a custom relevance algorithm that scores matches in titles higher than descriptions. Search results are:
- Calculated entirely in the browser (no API calls)
- Sorted by relevance score
- Filtered in real-time as the user types
- Displayed dynamically by cloning and inserting DOM elements

This approach trades off database-powered full-text search for zero infrastructure requirements while maintaining good UX for the expected content volume.

### Navigation System

**Sticky Navigation with Active State**: A fixed-position navbar remains visible during scroll, with active page highlighting. The mobile menu uses a toggle pattern with icon transformation (bars → X) to indicate state. This was chosen to:
- Provide constant access to navigation
- Give users clear visual feedback about their location
- Maintain usability on mobile devices

## External Dependencies

**Font Awesome 6.4.0 (CDN)**: Icon library loaded from CDN for vector icons throughout the UI. Used instead of custom SVGs to reduce maintenance and provide consistent iconography.

**Google Fonts - Inter (CDN)**: Modern sans-serif typeface loaded from Google Fonts CDN. Selected for its readability and professional appearance across different weights.

**No Backend Services**: The application is entirely client-side with no:
- Database connections
- API endpoints
- Authentication systems
- Server-side rendering
- Build processes

This architecture enables deployment to any static hosting service (GitHub Pages, Netlify, Vercel) with zero configuration.