# Knowledge Base & BAU Dashboard

A fully functional, multi-page Knowledge Base and Business As Usual (BAU) Dashboard website with modern UI/UX design. Built with pure HTML, CSS, and JavaScript - ready to deploy on GitHub Pages.

## 🚀 Features

### Knowledge Base
- **Organized Content**: Documentation categorized into Getting Started, FAQs, Tutorials, and Documentation
- **Smart Search**: Real-time search functionality to quickly find articles
- **Rich Content**: Sample articles with detailed information and guides
- **Category Navigation**: Easy browsing by topic

### BAU Dashboard
- **Interactive Tiles**: Quick access shortcuts to tools and resources
- **Organized Sections**: Reports & Analytics, Operations Tools, System Tools, and Quick Links
- **Visual Feedback**: Smooth animations and hover effects
- **Easy Customization**: Simply update tile links and content

### Design Features
- ✨ **Modern UI/UX**: Professional gradient backgrounds and card-based layouts
- 🌓 **Dark/Light Mode**: Theme toggle with localStorage persistence
- 📱 **Fully Responsive**: Perfect on desktop, tablet, and mobile devices
- 🎨 **Beautiful Icons**: Font Awesome icons throughout
- ⚡ **Smooth Animations**: CSS transitions and hover effects
- 🎯 **Easy Navigation**: Sticky navbar with mobile menu

## 📁 Project Structure

```
├── index.html              # Landing page
├── pages/
│   ├── knowledge-base.html # Knowledge base with search
│   └── dashboard.html      # BAU dashboard with tiles
├── css/
│   ├── main.css           # Core styles and layout
│   ├── theme.css          # Dark/light theme styles
│   ├── knowledge-base.css # Knowledge base specific styles
│   └── dashboard.css      # Dashboard specific styles
├── js/
│   ├── main.js            # Mobile menu functionality
│   ├── theme-toggle.js    # Theme switching logic
│   ├── search.js          # Search functionality
│   ├── articles.js        # Article content and navigation
│   └── dashboard.js       # Dashboard tile interactions
├── assets/
│   ├── icons/             # Custom icons (if needed)
│   └── images/            # Images and graphics
├── docs/                  # Knowledge base content
└── README.md              # This file
```

## 🎯 Quick Start

### Option 1: Deploy to GitHub Pages (Recommended)

1. **Upload to GitHub**
   - Create a new repository on GitHub
   - Upload all project files to your repository
   - Make sure all files maintain their folder structure

2. **Enable GitHub Pages**
   - Go to your repository Settings
   - Navigate to "Pages" in the left sidebar
   - Under "Source", select "Deploy from a branch"
   - Choose "main" branch and "/ (root)" folder
   - Click "Save"

3. **Access Your Site**
   - Your site will be available at: `https://yourusername.github.io/repository-name/`
   - GitHub Pages typically takes 1-2 minutes to build and deploy

### Option 2: Run Locally

#### Using Python (Recommended)
```bash
# Python 3
python -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000
```

#### Using Node.js
```bash
# Install http-server globally
npm install -g http-server

# Run server
http-server -p 8000
```

#### Using PHP
```bash
php -S localhost:8000
```

Then open your browser to `http://localhost:8000`

## 🛠️ Customization Guide

### Changing Colors

Edit the CSS variables in `css/main.css`:

```css
:root {
    --primary-color: #6366f1;      /* Main brand color */
    --secondary-color: #8b5cf6;    /* Secondary accent */
    --accent-color: #ec4899;       /* Highlights */
}
```

### Adding Dashboard Tiles

In `pages/dashboard.html`, add a new tile:

```html
<div class="dashboard-tile">
    <div class="tile-icon">
        <i class="fas fa-your-icon"></i>
    </div>
    <h3>Your Title</h3>
    <p>Your description</p>
    <button class="tile-button" onclick="handleTileClick('your-action')">
        Open <i class="fas fa-external-link-alt"></i>
    </button>
</div>
```

### Adding Knowledge Base Articles

1. Add article data in `js/articles.js`:

```javascript
'article-id': {
    title: 'Article Title',
    category: 'Category Name',
    content: `
        <h1>Article Title</h1>
        <p>Your content here...</p>
    `
}
```

2. Add article card in `pages/knowledge-base.html`:

```html
<article class="article-card" 
         data-category="category" 
         data-title="Title" 
         data-description="Description">
    <h3><i class="fas fa-icon"></i> Title</h3>
    <p>Description</p>
    <a href="#" class="article-link" data-article="article-id">
        Read More <i class="fas fa-arrow-right"></i>
    </a>
</article>
```

### Updating Site Name/Branding

Search and replace "KB & BAU Hub" in all HTML files with your desired name.

### Changing Fonts

In each HTML file's `<head>`, update the Google Fonts import:

```html
<link href="https://fonts.googleapis.com/css2?family=YourFont:wght@300;400;500;600;700&display=swap" rel="stylesheet">
```

Then update the font-family in `css/main.css`:

```css
body {
    font-family: 'YourFont', sans-serif;
}
```

## 📱 Mobile Responsiveness

The site is fully responsive with breakpoints at:
- **Desktop**: > 768px
- **Tablet**: 481px - 768px
- **Mobile**: ≤ 480px

Mobile menu automatically appears on smaller screens.

## 🎨 Icons

This project uses [Font Awesome](https://fontawesome.com/) icons. Browse available icons at:
https://fontawesome.com/icons

To use a different icon, replace the icon class:
```html
<i class="fas fa-icon-name"></i>
```

## 🌐 Browser Support

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)

## 📝 Content Management

### Knowledge Base Content

All article content is stored in `js/articles.js` as JavaScript objects. This approach:
- Makes editing easy (no database needed)
- Keeps content version-controlled
- Loads quickly on GitHub Pages
- Can be easily migrated to a CMS later

### Dashboard Links

Dashboard tiles currently show notifications when clicked. To link to real tools:

1. For external links, change the button to an anchor tag:
```html
<a href="https://your-tool-url.com" class="tile-button" target="_blank">
    Open <i class="fas fa-external-link-alt"></i>
</a>
```

2. For internal pages, link directly:
```html
<a href="your-page.html" class="tile-button">
    Open <i class="fas fa-external-link-alt"></i>
</a>
```

## 🔧 Troubleshooting

### GitHub Pages not loading CSS/JS
- Ensure all file paths are relative (no leading `/`)
- Check that files are in the correct folders
- Clear browser cache

### Search not working
- Make sure JavaScript is enabled
- Check browser console for errors
- Verify `js/search.js` is properly linked

### Theme not persisting
- Ensure localStorage is enabled in browser
- Check browser privacy settings
- Try a different browser

## 📄 License

This project is free to use and modify for personal and commercial purposes.

## 🤝 Contributing

Feel free to fork this project and customize it for your needs. Some ideas:
- Add more article categories
- Integrate with a CMS
- Add user authentication
- Connect dashboard tiles to real tools
- Add analytics tracking

## 📞 Support

For issues or questions:
1. Check the Knowledge Base (built right in!)
2. Review this README
3. Check browser console for errors

## 🎉 Credits

- **Design**: Custom modern UI/UX
- **Icons**: Font Awesome
- **Fonts**: Google Fonts (Inter)
- **Built with**: Pure HTML, CSS, and JavaScript

---

**Made for GitHub Pages** - No build tools, no dependencies, just upload and go! 🚀
